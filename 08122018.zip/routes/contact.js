const express = require('express')
const chalk = require('chalk')
const validators = require('../validators')
const userQueryDao = require('../dao').query
const Messages = require('../constant/messages')

const nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
const sgTransport = require('nodemailer-sendgrid-transport');
const xoauth2 = require('xoauth2')
const router = express.Router();

router.get('/', function(req, res, next) {
  res.render(
  'contact-us', {
    title: 'Contact Us',
    message: 'Hello there!'
  })
})

router.post('/', function(req, res, next) {
  validators.validateUserQuery.userQueryValidator(req.body)
    .then((value) => {
      return userQueryDao.insertUserQuery(value)
    })
    .then((query) => {
      console.log(query)
      var transporter = nodemailer.createTransport({
        service:"Gmail",
        auth:{
          type: process.env.GMAIL_AUTH_TYPE,
          user: process.env.ADMIN_EMAIL,
          clientId: process.env.GMAIL_AUTH_CLIENT_ID,
          clientSecret: process.env.GMAIL_AUTH_CLIENT_SECRET,
          refreshToken: process.env.GMAIL_AUTH_REFRESH_TOKEN
        }
      });

      var mailOptions = {
         from: Messages.queryEmailAddress,
         to: process.env.ADMIN_EMAIL,
         subject: Messages.querySubject + `${query.subject}`,
         //text: `User Name: "${query.fullName}" <${query.email}> : ${query.message}`,
          html: `<p>User's Name: <b>${query.fullName}</b></p><p>User's Email: <b>${query.email}</b></p><br><p><b>User's Query<b></p><p>${query.message}</p>`
      };
      transporter.sendMail(mailOptions, function(error, info){
        if(error){
            return res.send(error);
        }
        //return res.send("mail send successfully");
        res.redirect('thank-you')
      });
    })
    .catch((err) => {
      console.log("error condition in post contact\n", err.message )
    })

})

module.exports = router
