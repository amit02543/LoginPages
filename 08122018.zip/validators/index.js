const search = require('./search')
const registration = require('./register')
const authorReg = require('./author')
const userQuery = require('./user-query')

module.exports = {
  validateSearchPage: search,
  validateRegisterPage: registration,
  validateUserQuery: userQuery,
  author: authorReg
}
