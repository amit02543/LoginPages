$(document).ready(function(){
  setTimeout(function(){ $('.alert').fadeOut() }, 5000);

  if ( window.location.pathname === '/books') {
      $("#searchResult").dataTable({
          responsive: true,
          "aoColumnDefs": [{
              "bVisible": true
          }],
          "autoWidth": true,
          "processing": true,
          paginate: true,
          //"scrollX": true,
          "pageLength": 20,
          "searching": false,
          "lengthChange": false,
          "order": []
      })
  }


  if(window.location.pathname === '/home'){
    //$("#homepage").scrollspy()
  //  $('body').scrollspy({ target: '.home-container' });
  }

  $("#updateProfileImg").click(function(){
    $("#profileModal").modal();
  });

  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
          scrollTop: $(hash).offset().top
        }, 900, function(){
          window.location.hash = hash;
        });
    }
  });

  $("[name='seriesBook']").on('change',function(){
  	if($(this).val()==='y'){
  		$(".seriesName-wrapper, .seriesBundle-wrapper").addClass('show').removeClass('hide')
  	} else {
  		$(".seriesName-wrapper, .seriesBundle-wrapper").addClass('hide').removeClass('show')
      }
  })

 $(".close-btn").click(function(){$(".overlayContainer").hide()})
  // $('#categories').selectize({
  //   load: function(query, callback) {
  //     if (!query.length) return callback();
  //     $.ajax({
  //       url: 'localhost:4000/genres/all',
  //       type: 'GET',
  //       dataType: 'jsonp',
  //       data: {
  //         q: query,
  //         page_limit: 10
  //       },
  //       error: function() {
  //         callback();
  //       },
  //       success: function(res) {
  //         console.log(res.genre);
  //         callback(res.genre);
  //       }
  //     });
  //   }
  // });

  // $(".dropdown-menu li").click(function() {
  //   var url = window.location.href;
  //   var activeTab = url.substring(url.indexOf("#") + 1);
  //   $(".tab-pane").removeClass("active in");
  //   $("#" + activeTab).addClass("active in");
  //   $('a[href="#'+ activeTab +'"]').tab('show')
  //   //window.location.href = 'http://localhost:4040/account/profile#'+activeTab
  //   location. reload(true);
  // })

  $('#password').keyup(function(e){
    if(e.which===8 || e.which===46){
      return validatePasswords()
    }
    var password = $('#password').val()
    var confirmPass = $('#confirmPassword').val()
    var lastChar = password.substring(password.length-1,)
    if (password.length>=8) {
      $(".lengthCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([a-z])/)) {
      $(".lowerCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([A-Z])/)) {
      $(".upperCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([0-9])/)) {
      $(".numberCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
      $(".specialCharCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password === confirmPass) {
      $(".confirmCheck").addClass("checked").removeClass("error").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    } else {
      $(".confirmCheck").addClass("error").removeClass("checked").find("i").removeClass("fa-check-square-o").addClass("fa-square-o")
    }
  })

  function validatePasswords() {
    $(".lengthCheck, .lowerCaseCheck, .upperCaseCheck, .numberCheck, .specialCharCheck, .confirmCheck").removeClass("error checked").find("i").addClass("fa-square-o").removeClass("fa-check-square-o")
    var password = $('#password').val()
    var confirmPass = $('#confirmPassword').val()
    var lastChar = password.substring(password.length-1,)
    if (password.length>=8 && confirmPass.length>=8) {
      $(".lengthCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([a-z])/) && confirmPass.match(/([a-z])/)) {
      $(".lowerCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([A-Z])/) && confirmPass.match(/([A-Z])/)) {
      $(".upperCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([0-9])/) && confirmPass.match(/([0-9])/)) {
      $(".numberCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/) && confirmPass.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
      $(".specialCharCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password === confirmPass) {
      $(".confirmCheck").addClass("checked").removeClass("error").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    } else {
      $(".confirmCheck").addClass("error").removeClass("checked").find("i").removeClass("fa-check-square-o").addClass("fa-square-o")
    }
  }

  function checkPasswords(){
    var currentPassword = $("#currentPassword").val()
    var newPassword = $("#password").val()
    var confirmPassword = $("#confirmPassword").val()
    if(currentPassword!=="" && validateConditions(newPassword, confirmPassword)){
      return true
    }
    return false
  }

  function validateConditions(password, confirmPass){
    if(password.length>=8 && password.match(/([a-z])/) && password.match(/([A-Z])/)
      && password.match(/([0-9])/) && password.match(/([!,%,&,@,#,$,^,*,?,_,~])/) && password === confirmPass) {
      return true
    }
    return false
  }

  $("#confirmPassword").keyup( function(e) {
    var password = $('#password').val()
    var confirmPass = $('#confirmPassword').val()
    if(password.length===0){
      return false;
    }
    if(e.which===8 || e.which===46){
      return validatePasswords()
    }
    if (password.length>=8) {
      $(".lengthCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([a-z])/)) {
      $(".lowerCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([A-Z])/)) {
      $(".upperCaseCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([0-9])/)) {
      $(".numberCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
      $(".specialCharCheck").addClass("checked").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    }
    if (password === confirmPass) {
      $(".confirmCheck").addClass("checked").removeClass("error").find("i").removeClass("fa-square-o").addClass("fa-check-square-o")
    } else {
      $(".confirmCheck").addClass("error").removeClass("checked").find("i").removeClass("fa-check-square-o").addClass("fa-square-o")
    }
  })


  $("#query").keydown(function(event) {
    if(event.which == 13) {
      event.preventDefault();
      $("#search-btn").trigger('click');
    }
  })

  $("#mobquery").keydown(function(event) {
    if(event.which == 13) {
      event.preventDefault();
      $("#mobSearch-btn").trigger('click');
    }
  })

  if(window.location.pathname === '/register/part-two'){
    $('#sandbox-container input').datepicker({
      format: "M-yyyy",
      endDate: "0d",
      startView: 2,
      minViewMode: 1,
      autoclose: true
    });
  }


  if(window.location.pathname === 'addAuthor' || window.location.pathname.indexOf('profile') != -1){
    $('#dob-container input#dob').datepicker({
      format: "mm/dd/yyyy",
      endDate: "0d",
      startView: 3,
      autoclose: true
    });
  }

  if(window.location.pathname === 'addAuthor'){
    $('.datepicker').datepicker({
      endDate: "0 days",
      startView: 3,
      autoclose: true,
      todayHighlight: true
    });
  }

  $("#layout button, #order button").click(function() {
    $(this).addClass("active").siblings().removeClass("active");
    var view = $(this).attr("id");
    console.log("view : ", view);
    formURL();
  })

  $("#filter").on('change', function() {
    var filter = $(this).val();
    console.log("Filter : ", filter);
    formURL();
  })

  $(".display-mode a").click(function(e){
  	//e.preventDefault();
  	$(this).addClass("active").siblings().removeClass("active")
  })

  $(".sort-type").click(function(e){
    $(this).addClass("active").siblings().removeClass("active asc desc")
      //.find("span.glyphicon-triangle-bottom, span.glyphicon-triangle-top").addClass("hide")
    	var classes = $(this).attr("class");
    	if(classes.indexOf("desc") > 0){
    		$(this).addClass("asc").removeClass("desc")
    		//$(this).find("span.glyphicon-triangle-bottom").addClass("hide")
    		//$(this).find("span.glyphicon-triangle-top").removeClass("hide")
        $(this).find("i").addClass("fa-sort-asc").removeClass("fa-sort-desc fa-sort")
      } else {
    		$(this).addClass("desc").removeClass("asc")
    		//$(this).find("span.glyphicon-triangle-bottom").removeClass("hide")
    		//$(this).find("span.glyphicon-triangle-top").addClass("hide")
        $(this).find("i").addClass("fa-sort-desc").removeClass("fa-sort-asc fa-sort")
      }
      //e.preventDefault();
      formURL()
    })

  $("button#cancel").click(function() {
    ajaxGetCall(window.location.origin+'/home')
  })

  //For providing rating
  $(".rating span i").click(function(){
  	var value = $(this).parent().attr("value");
  	$(".rating span").each(function(index){
  		console.log(index + " : " + value)
  		if(index < value){
  			$(this).find(".fa-star-o").css("display", "none");
  			$(this).find(".fa-star").css("display", "inherit").css("color","green")
  		}
  	})
  })

  // var reviewCount = 1;
  // $("#reviewBtn").click( function() {
  //   $("#book-reviews").prepend('<div class="review-container"><p class="col-sm-6 reviewer"><strong>Amit Kumar : '+ reviewCount
  //     +'</strong></p><div class="col-sm-6"><div class="rating pull-right"><span value="1"></span><span value="2"></span><span value="3"></span><span value="4"></span><span value="5"></span></div></div><textarea class="form-control reviewArea" placeholder="Enter your review here">'
  //     + '</textarea><div class="button-container"><input type="button" class="btn btn-default col-md-2 reviewBtn" value="Submit"/>'
  //     + '<input type="button" class="btn btn-default col-md-2 reviewCancelBtn" value="Cancel" /></div>')
  //   reviewCount++;
  // })
  //
  // $(".reviewCancelBtn").click( function() {
  //   $("#book-reviews").find(".review:first-child").remove()
  //   reviewCount--;
  // })

  //TODO: need to work on update method based on new form
  $(".update").click(function() {
      var rowElem = $(this).parent().siblings();
      var title, author, category;
      var id = $(this).parent().parent().attr('data-id')
      rowElem.each(function() {
          if ($(this).prop('className') == 'title') {
              title = $(this).prop('innerText')
          }
          if ($(this).prop('className') == 'author') {
              author = $(this).prop('innerText')
          }
          if ($(this).prop('className') == 'category') {
              category = $(this).prop('innerText')
          }
      })
      $(".modal-body #bookId").val(id);
      $(".modal-body #book-title").val(title);
      $(".modal-body #book-author").val(author);
      $(".modal-body #book-category").val(category);
      $('#myModal').modal('show');
  })

  $("#update-book").click(function() {
    var title = $("#book-title").val();
    var author = $("#book-author").val();
    var category = $("#book-category").val();
    var id = $("#bookId").val();
    var book = { 'title': title, 'author': author, 'category': category, 'id': id }
    $.ajax({
        type: 'PUT',
        dataType: 'json',
        contentType: 'application/json',
        url: "/books",
        headers: {"X-HTTP-Method-Override": "PUT"},
        data: JSON.stringify(book)
    }).done(function() {
      alert("Update successful");
    });
  })

  $(".remove").click(function(){
    var left = $(this).offset().left-220;
    var top = $(this).offset().top-85;
    var bookId = $(this).parent().parent().attr("data-id")
    console.log(left+"\t"+top+"\t"+bookId)
    $("#book-id").val(bookId);
    $("#deleteContainer").css('left', left+'px').css('top', top+'px').show()
    $(".overlayContainer").show();
  })

  // $("#cancelBtn,.overlayContainer").click(function(){
  //   $("#deleteContainer,.overlayContainer").hide()
  // })

  $("#deleteBtn").click(function() {
      var id = $("#book-id").val();
      var book = {'id': id }
      $.ajax({
          type: 'DELETE',
          dataType: 'json',
          contentType: 'application/json',
          url: "/books",
          headers: {"X-HTTP-Method-Override": "DELETE"},
          data: JSON.stringify(book)
      }).done(function() {
        $("#deleteContainer").hide();
        alert("Deletion successful");
      });
  })

  //TODO: tags not working properly


 //  $(".tagsManager").tagsManager({
 //     prefilled: ["Pisa", "Rome"],
 //     CapitalizeFirstLetter: true,
 //     preventSubmitOnEnter: true,
 //     typeahead: true,
 //     typeaheadAjaxSource: null,
 //     typeaheadSource: ["Pisa", "Rome", "Milan", "Florence", "New York", "Paris", "Berlin", "London", "Madrid"],
 //     delimeters: [44, 188, 13],
 //     backspace: [8],
 //     blinkBGColor_1: '#FFFF9C',
 //     blinkBGColor_2: '#CDE69C',
 //     hiddenTagListName: 'hiddenTagListA'
 // });


 // $( function() {
 //     function split( val ) {
 //       return val.split( /,\s*/ );
 //     }
 //     function extractLast( term ) {
 //       return split( term ).pop();
 //     }
 //
 //     $( "#birds" )
 //       // don't navigate away from the field on tab when selecting an item
 //       .on( "keydown", function( event ) {
 //         if ( event.keyCode === $.ui.keyCode.TAB &&
 //             $( this ).autocomplete( "instance" ).menu.active ) {
 //           event.preventDefault();
 //         }
 //       })
 //       .autocomplete({
 //         source: function( request, response ) {
 //           $.getJSON( "search.php", {
 //             term: extractLast( request.term )
 //           }, response );
 //         },
 //         search: function() {
 //           // custom minLength
 //           var term = extractLast( this.value );
 //           if ( term.length < 2 ) {
 //             return false;
 //           }
 //         },
 //         focus: function() {
 //           // prevent value inserted on focus
 //           return false;
 //         },
 //         select: function( event, ui ) {
 //           var terms = split( this.value );
 //           // remove the current input
 //           terms.pop();
 //           // add the selected item
 //           terms.push( ui.item.value );
 //           // add placeholder to get the comma-and-space at the end
 //           terms.push( "" );
 //           this.value = terms.join( ", " );
 //           return false;
 //         }
 //       });
 //   } );

// var optionalFields = ['contributors', 'series-name', 'series-bundle']
//
//    $("form").submit(function(event){
//     var formData = $( this ).serializeArray()
//     //  console.log( JSON.stringify(formData) );
//     event.preventDefault();
//
//     //  var fields = {};
//     //  $("#new-book").find("input, textarea").each(function() {
//     //   	var name = this.name, value = $(this).val();
//     //     if(value.indexOf(";")!=-1){
//     //         var val = value.substring(0,value.lastIndexOf(";"));
//     //         var arry = val.split(";");console.log('arry: ', arry);
//     //         value = arry
//     //         console.log('value : ', val, ' original: ', value )
//     //       }
//     //       fields[name] = value;
//     // });
//     // console.log("data:: ", JSON.stringify(fields))
//     //  var reformattedArray = formData.map(function(obj) {
//     //  var rObj = {};
//     //   if(obj.value.indexOf(";")!=-1){
//     //   var val = obj.value.substring(0,obj.value.lastIndexOf(";"));
//     //   console.log('value : ', val, ' original: ', obj.value )
//     //   var arry = val.split(";");console.log('arry: ', arry);
//     //   obj.value = arry
//     //   }
//     //      rObj[obj.name] = obj.value;
//     //      return rObj;
//     //   });
//
//     //  var errorList = [];
//     //  $(".error-msg").html("")
//     //  $(".form-group").each(function(i) {
//     //    var id = $(this).find('input,textarea').attr('id')
//     //    var value = $(this).find('input, textarea').val();
//     //    var pos = $.inArray(id, optionalFields)
//     //   console.log(value)
//     //   //TODO: other than empty field validation
//     //   if(pos<0 && (value==="" || value===undefined) ) {
//     //     errorList.push(id)
//     //     $(this).addClass("has-error")
//     //     $(this).find(".error-msg").html("<p class='error'>Field is mandatory</p>")
//     //   } else {
//     //     $(this).removeClass("has-error")
//     //   }
//     // })
//
//     // if(errorList.length<=1){
//     //   var data = JSON.stringify( $(form).serializeArray() );
//     //   console.log( data );
//     //   alert("Submitted");
//     // } else {
//     //   console.log("Error list: ", errorList)
//     //   $.each(errorList, function(index,value){
//     //     $("#"+value).parent().parent().addClass("has-error")
//     //   })
//     //   return false
//     // }
//
//     $.ajax({
//         type: 'POST',
//         dataType: 'json',
//         contentType: 'application/json',
//         url: "/books",
//         headers: {"X-HTTP-Method-Override": "POST"},
//         data: JSON.stringify(formData)
//     }).done(function(data) {
//       $(".error-msg").html('');
//       $("div.has-error").removeClass("has-error")
//       $("#successMsg").html(data.successMsg)
//         var errors = data.errorObj
//         var errorFields = Object.keys(errors)
//         for(var i=0; i<errorFields.length; i++) {
//           var field = errorFields[i];
//           var messages = errors[field];
//           $("[name="+field+"]")
//             .parent().addClass("has-error")
//             .siblings('.error-msg').html("<p>"+messages[0].message+"</p>")
//         }
//     }).fail(function(err) {
//       console.log( "error : ", err.message );
//     })
//
//   });

  $("#search-btn").click(function() {
    // var query = $("#query").val();
    // var searchType = $("[name=search-category]:checked").attr("id");
    // var url = window.location.origin + '/books?q=' + query + '&type=' +
    //           searchType + '&layout=compact-view&filter=' +
    //           searchType.substring(0,searchType.indexOf("-")) + '&order=asc';
    // ajaxGetCall(url);
    formURL()
  })

  $("#search-btn").click(function() {
    var query = $("#query").val()
    var searchType = $("[name=search-category]:checked").attr("id");
    var url = window.location.origin + '/books?q=' + query + '&type=' +
              searchType + '&layout=compact-view&filter=' +
              searchType.substring(0,searchType.indexOf("-")) + '&order=asc';
    ajaxGetCall(url)
  })

  $("#mobSearch-btn").click(function() {
    var query = $("#mobquery").val()
    var searchType = $("#mobSearch-category").val().toLowerCase()+'-search'
    var url = window.location.origin + '/books?q=' + query + '&type=' +
              searchType + '&layout=compact-view&filter=' +
              searchType.toLowerCase() + '&order=asc';
    ajaxGetCall(url)
  })

  $(".details").click(function(){
    var id = $(this).parents('.flip-container').attr("data-id");
    console.log("id: ", id)
    ajaxGetCall(window.location.origin + '/books/' + id);
  })

  $(".downloads, .likes, .dislikes").click(function() {
    var counts = $(this).siblings('.counts')[0].innerHTML.trim()
    $(this).siblings('.counts')[0].innerHTML = parseInt(counts) + 1
    $(this).addClass('active')
  })

})

function formURL() {
  // var url = window.location.origin + '/books?';
  // url += 'layout=' + $("#layout button.active").attr("id");
  // url += '&filter=' + $("#filter").val();
  // url += '&order=' + $("#order .active").attr("id");
  var activeFilter = $(".sorting span.active").attr("id")
  var query = $("#query").val();
  var view = 'compact-view';
  var searchType = $("[name=search-category]:checked").attr("id");
  var q = $(".display-mode").find("a.active").attr("href");
  if(q!==undefined){
    var partial = q.substring(q.indexOf("layout")+7,);
    view = partial.substring(0,partial.indexOf("&")) || 'compact-view';
  }
  var filter = activeFilter || searchType.substring(0,searchType.indexOf("-"))
  var order = 'asc'
  if(activeFilter){
    var className = $("#"+activeFilter).attr('class').split(" ")
    order = className[2] || 'asc'
  }
  var url = window.location.origin + '/books?q=' + query + '&type=' +
            searchType + '&layout=' + view + '&filter=' +
            filter + '&order=' + order;
  ajaxGetCall(url);
}

function ajaxGetCall(url) {
  $.ajax({
    url: url,
    method: 'GET',
    headers: {'Content-type': 'application/json'},
    datatype: 'json',
    // success: function() {
    //   //alert('Success')
    //   location.replace(url)
    // },
    // error: function() {
    //   alert('error')
    // }
    success: function(msg){
       //alert( "Data Saved: " + msg );
       location.replace(url)
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
      alert("some error: ", errorThrown.message);
    }
  })
}

$(document).ready(function(){
  //$('#example').DataTable();
  if(window.location.search.length>0 ){
     var queryStr = window.location.search.substring(1);
     var queries = queryStr.split("&")
     var q, type, view, sort, order;

     $.each(queries, function(index, query) {
       var pairs= query.split("=")
       if(pairs[0]==='q'){
         $("#query").val(pairs[1])
         q = pairs[1]
       }
       if(pairs[0]==='type'){
         $("[name=search-category]#"+pairs[1]).prop("checked",true)
         type = pairs[1]
       }
       if(pairs[0]==='layout'){
         $("#layout button#"+pairs[1]).addClass("active").siblings().removeClass("active")
         view = pairs[1]
       }
       if(pairs[0]==='order'){
         $("#order button#"+pairs[1]).addClass("active").siblings().removeClass("active")
         order = pairs[1]
       }
       if(pairs[0]==='filter'){
         //$("#filter").val(pairs[1])
         $(".sort-type#"+pairs[1]).addClass("active").siblings().removeClass("active")
         sort = pairs[1]
       }
     })

     $(".display-mode a").each(function(){
       var elemClass = $(this).attr("class").split(" ")[0];
       var uri = '?q='+q+'&type='+type+'&layout='+elemClass+'-view&filter='+sort+'&order='+order
       $(this).attr("href", uri)
     })

     $(".sorting span.sort").each(function(){
       var elemClasses = $(this).attr("class").split(" ");
       var elemOrder = (elemClasses.length)>1?elemClasses[2]:'asc';
       //var uri = '?q='+q+'&type='+type+'&layout='+view+'&filter='+elemClasses[0]+'&order='+elemOrder;
       // $(this).attr('href',uri)
     })
     console.log("here we can form urls")
     $(".display-mode a."+view.substring(0,view.indexOf('-'))).addClass("active").siblings().removeClass("active")
     //$(".sorting span").removeClass("active asc desc").find("span.glyphicon").addClass('hide')
     $(".sorting span").removeClass("active asc desc")
     $(".sorting span#"+sort).addClass("active "+order)
     if(order==='asc'){
       $(".sorting span#"+sort).find("i").addClass("fa-sort-asc").removeClass("fa-sort-desc fa-sort")
       //$(".sorting span#"+sort).find('span.glyphicon-triangle-top').removeClass('hide')
     } else {
       $(".sorting span#"+sort).find("i").addClass("fa-sort-desc").removeClass("fa-sort-asc fa-sort")
       //$(".sorting span#"+sort).find('span.glyphicon-triangle-bottom').removeClass('hide')
     }
   }

  $("#first-book").submit(function(event){
   var formData = jQuery.param($( this ).serializeArray());
   console.log('formdata page 1 : ', formData)
  })

  $("#second-book").submit(function(event){
   var formData = $( this ).serializeArray();
   console.log('formdata page 2 : ', formData)
  })


  $(".showLink").click(function(){
    $(this).parent().siblings('input[type="password"]').attr("type", "text");
    $(this).addClass("hide").siblings().removeClass("hide")
  })

  $(".hideLink").click(function(){
    $(this).parent().siblings('input[type="text"]').attr("type", "password");
    $(this).addClass("hide").siblings().removeClass("hide")
  })

  /* Multiple page registration form code start */

  $(".next").click(function(){
    $(this).parents("fieldset").hide().next().show()
  })

  $(".previous").click(function(){
    $(this).parents("fieldset").hide().prev().show()
  })

  $("nav span").click(function(){
    var pageId = $(this).attr('data-page-id')
    $("form fieldset#"+pageId).show().siblings().hide()
  })

  /* Multiple page registration form code end */



  /*Bar rating inititali*/
  // $('#example').barrating({
  //       theme: 'fontawesome-stars',
  //       initialRating:"0"
  // });
  // $('#example2').barrating({
  //     theme: 'fontawesome-stars-o',
  //     initialRating:3.6,
  //     readonly:true,
  //     showSelectedRating:true
  // });

  if ( window.location.pathname.indexOf("/books/") === 0) {
      $('#example').barrating({
          theme: 'fontawesome-stars',
          initialRating: "0"
      });
      $('#example2').barrating({
          theme: 'fontawesome-stars-o',
          initialRating: 3.6,
          readonly: true,
          showSelectedRating: true
      });
      var userRating = $(".userRating")[0].innerText.split(" ")[0]
      $('#bookRating').barrating({
          theme: 'fontawesome-stars-o',
          initialRating: userRating,
          readonly: true,
          showSelectedRating: true
      });
  }


})




// $("#insert-book").click(function() {
//     var title = $("#book-title").val();
//     var author = $("#book-author").val();
//     var category = $("#book-category").val();
//     var book = { 'title': title, 'author': author, 'category': category }
//     $.ajax({
//         type: 'POST',
//         dataType: 'json',
//         contentType: 'application/json',
//         url: "/books",
//         headers: {"X-HTTP-Method-Override": "POST"},
//         data: JSON.stringify(book)
//     }).done(function() {
//       alert("Successfully inserted");
//     });
//   })
//
//   $("#update-book").click(function() {
//     var title = $("#book-title").val();
//     var author = $("#book-author").val();
//     var category = $("#book-category").val();
//     var id = $("#book-id").val();
//     var book = { 'title': title, 'author': author, 'category': category, 'id': id }
//     $.ajax({
//         type: 'PUT',
//         dataType: 'json',
//         contentType: 'application/json',
//         url: "/books",
//         headers: {"X-HTTP-Method-Override": "PUT"},
//         data: JSON.stringify(book)
//     }).done(function() {
//       alert("Update successful");
//     });
//   })
//
//   $("#deleteBtn").click(function() {
//     var id = $(this).val();
//     var book = {'id': id }
//     $.ajax({
//         type: 'DELETE',
//         dataType: 'json',
//         contentType: 'application/json',
//         url: "/books",
//         headers: {"X-HTTP-Method-Override": "DELETE"},
//         data: JSON.stringify(book)
//     }).done(function() {
//       $("#deleteContainer").hide();
//       alert("Deletion successful");
//     });
//   })
