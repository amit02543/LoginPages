const bookModel = require('./book')
const userQueryModel = require('./user-query')
const genreModel = require('./genre')

module.exports = {
  books:bookModel,
  userquery: userQueryModel,
  genres: genreModel
}
