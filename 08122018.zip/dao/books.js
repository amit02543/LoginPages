var Book = require('../model').books;
var bookDao = {}

bookDao.searchBooksByFilterCriteria = (criteria)=>{
  const {title,author,category,sortParam} = criteria
  return Book.find({
          title: new RegExp(title, "i"),
          author: new RegExp(author, "i"),
          category: new RegExp(category, "i")
      }).sort(sortParam).lean().exec()
}

bookDao.searchBooksByTitle = (criteria)=>{
  const {title,author,category,sortParam} = criteria

  console.log('title: ', title, ' sortParam: ', sortParam)

  // if(Object.keys(sortParam) == 'title') {
  //   sortParam = {score:{$meta: 'textScore'}}
  //   console.log('sortParam: ', sortParam)
  // }

  return Book.find({
          $text:{$search: title}
        },
        { score: {
          $meta: 'textScore'
        }}
      ).lean().exec()
      //).sort(sortParam).lean().exec()
}

bookDao.getBookById = (id) => {
  return Book.findOne({
        _id: id
      }).exec()
}

bookDao.insertBookDeails = (book) => {
  console.log("Insert book: ", book)
  var bookDetails = new Book(book)
  return bookDetails.save()
}

bookDao.updateBookById = (reqBody) => {
  return Book.findOneAndUpdate({
          _id: reqBody.id
      }, {
          $set: {
              title: reqBody.title,
              category: reqBody.category,
              author: reqBody.author
          }
      }, {
          upsert: true
      })
}

bookDao.removeBookById = (id, review) => {
  return Book.findOneAndRemove({
      _id: id
  })
}

bookDao.insertBookReview = (id, rating, review, userId, name) => {
  console.log('dao : ', id, " ", rating, " ", review, " ", userId, " ", name)
  return Book.update({
    _id: id
  }, {
    $push:{
      "reviews": {
        "review": review,
        "rating": rating,
        "userId": userId,
        "displayName": name
      }
    }
  })
}

bookDao.updateDownloadsById = (id) => {
  return Book.update({
    _id: id
  }, {
    $inc: {
      "downloads": 1
    }
  })
}

bookDao.updateLikesById = (id) => {
  return Book.update({
    _id: id
  }, {
    $inc: {
      "likes": 1
    }
  })
}

bookDao.updateDislikesById = (id) => {
  return Book.update({
    _id: id
  }, {
    $inc: {
      "dislikes": 1
    }
  })
}

module.exports = bookDao
