const Joi = require('joi')
const priceRegex = /^[1-9]\d*(((,\d{3}){1})?(\.\d{0,2})?)$/;
const joiOptions = { convert: true, abortEarly: false };

const registrationSchema = Joi.object().keys({
  title: Joi.string().required().min(3).max(50),
  author: Joi.string().min(3).max(50).required(),
  contributors: Joi.string().allow('').min(3).max(100).optional(),
  edition: Joi.string().min(3).max(20).required(),
  description: Joi.string().min(20).max(500).required(),
  pages: Joi.number().integer().required(),
  keywords: Joi.array().items(Joi.string()).required(),
  category: Joi.array().items(Joi.string()).required(),
  language: Joi.string().min(3).max(20).required(),
  seriesName: Joi.string().allow('').min(3).max(50).optional(),
  seriesBundle: Joi.array().allow('').items(Joi.string()).optional(),
  publisher: Joi.string().min(3).max(100).required(),
  publishYear: Joi.date().required(),
  isbn: Joi.string().regex(/^[0-9]{1}\d{12}$/).required(),
  price:Joi.number().precision(2).required(),
  imageURL:Joi.string().regex(/((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/
).required()
});

const registrationPartOneSchema = Joi.object().keys({
  title: Joi.string().required().min(3).max(50),
  author: Joi.string().min(3).max(50).required(),
  contributors: Joi.string().allow('').min(3).max(100).optional(),
  description: Joi.string().min(20).max(500).required()
})

const registrationPartTwoSchema = Joi.object().keys({
  publisher: Joi.string().min(3).max(100).required(),
  publishYear: Joi.date().required(),
  edition: Joi.string().min(3).max(20).required(),
  isbn: Joi.string().regex(/^[0-9]{1}\d{12}$/).required(),
  price:Joi.number().precision(2).required(),
  pages: Joi.number().integer().required(),
  //category: Joi.array().items(Joi.string()).required(),
  category: Joi.string().required(),
  language: Joi.string().min(3).max(30).required()
})

const registrationPartThreeSchema = Joi.object().keys({
  seriesName: Joi.string().allow('').min(3).max(50).optional(),
  //seriesBundle: Joi.array().allow('').items(Joi.string()).optional(),
  seriesBundle: Joi.string().allow('').min(3).max(200).optional(),
  //keywords: Joi.array().items(Joi.string()).required()
  keywords: Joi.string().required()
})

const bookReviewSchema = Joi.object().keys({
  rating: Joi.number().integer().required(),
  bookId: Joi.string().required(),
  review: Joi.string().required()
})

const validateRegQuery = (query) => {
  return new Promise((resolve, reject) => {
    Joi.validate(query, registrationSchema, joiOptions, (err, value) => {
      if(err){
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

const validateRegistrationPartOne = (query) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(query, registrationPartOneSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

const validateRegistrationPartTwo = (query) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(query, registrationPartTwoSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

const validateRegistrationPartThree = (query) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(query, registrationPartThreeSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

const validateUserReview = (review) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(review, bookReviewSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

module.exports = {
  validateRegQuery,
  validateRegistrationPartOne,
  validateRegistrationPartTwo,
  validateRegistrationPartThree,
  validateUserReview
}
