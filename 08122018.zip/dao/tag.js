var tagDao = {};
const Tag = require('../model').tags;

tagDao.listTag = (query, pageLimit) => {
  return Tag.find({
      keyword: new RegExp(query, "i")
  },
  { _id: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

module.exports = tagDao
