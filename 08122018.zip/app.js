const express = require('express');
const dotenv = require('dotenv').config({path: '.env'})
const app = express();
const bodyParser = require('body-parser');
const methodOverride = require('method-override')
const logger = require('morgan');
const router = require('./routes')
const favicon = require('serve-favicon')
const path = require('path');
const cors = require('cors')
const mongoose = require('mongoose');
const session = require('express-session');
const lusca = require('lusca');
const MongoStore = require('connect-mongo')(session);
const flash = require('express-flash');
const passport = require('passport');
const passportConfig = require('./config/passport');
const chalk = require('chalk')
const multer = require('multer');
const Errors = require('./constant/errors')
const Messages = require('./constant/messages')
const config = require('./config/config.json')
const size = require('window-size')
//const Window = require('window');

//const window = new Window();


const upload = multer({ dest: path.join(__dirname, 'uploads') });

//const db = process.env.MONGOURL
const db = 'mongodb://heroku_z1sgh76c:9fekn948ia6934sh4mbgq60616@ds113795.mlab.com:13795/heroku_z1sgh76c';
const port = process.env.PORT;

/**
 * API keys and Passport configuration.
 */
//const passportConfig = require('./config/passport');

//connect to MongoDB
// mongoose.connect('mongodb://localhost/example');
// var db = mongoose.connection;
//
// //handle mongo error
// db.on('error', console.error.bind(console, 'Database connection error:'));
// db.once('open', function () {
//   console.log(chalk.green('Database connected'))
// });

/**
 * Connect to MongoDB.
 */
// mongoose.Promise = global.Promise;
// mongoose.connect('mongodb://localhost/example');
// //mongoose.connect('mongodb://heroku_z1sgh76c:9fekn948ia6934sh4mbgq60616@ds113795.mlab.com:13795/heroku_z1sgh76c')
// mongoose.connection.on('error', (err) => {
//   console.error(err);
//   console.log('%s MongoDB connection error. Please make sure MongoDB is running.', chalk.red('✗'));
//   process.exit();
// });

mongoose.connect(db).then(
  () => {
    console.log(chalk.green('Database connected: ', req.headers['user-agent']))
   },
  err => {
    console.error(err);
    console.log('%s MongoDB connection error. Please make sure MongoDB is running.', chalk.red('✗'));
    process.exit();
  }
);

//use sessions for tracking logins
// app.use(session({
//   secret: 'SessionSecret',
//   resave: true,
//   saveUninitialized: false,
//   store: new MongoStore({
//     mongooseConnection: db
//   })
// }));

// mongoose.connect(db).then(
//   () => {
//     console.log(chalk.green('Database connected'))
//    },
//   err => { console.log(chalk.red('Error occurred')) }
// );

const loggerFunc = function ( req, res, next ) {
  console.log( req.method + " request for " + req.originalUrl + " at : " + Date.now()
          + " screen res: " + size.width + "px X " + size.height + "px " + req.headers['user-agent'])
  next()
}

process.stdout.on('resize', function() {
  console.log(size.get());
});


//TODO: code clean up

//TODO: Insert data in database

//TODO: Data cache

app.set('view engine', 'pug')
app.use(cors())
app.use(express.static(__dirname + '/public'));

// app.use('/js', express.static(__dirname + '/public/js'));
// app.use('/node_modules', express.static(__dirname + '/node_modules'));
// app.use('/css', express.static(__dirname + '/public/css'));

app.use(favicon(path.join(__dirname, '/public/images', 'favicon.png')))
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(methodOverride('_method'))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  resave: true,
  saveUninitialized: true,
  secret: 'SessionSecret',
  store: new MongoStore({
    url: process.env.MONGOURL,
    autoReconnect: true,
    clear_interval: 3600
  })
}));

var middleware = {

    render: function (view) {
        return function (req, res, next) {
            res.render(view);
        }
    },

    globalLocals: function (req, res, next) {
        // res.locals.siteTitle="My Website's Title",
        // res.locals.pageTitle="The Root Splash Page",

        res.locals.author="Amit Kumar",
        res.locals.description="My app's description",
        res.locals.device=req.headers['user-agent'],
        //res.locals.deviceWidth=window.outerWidth,
        // res.locals.page1status="not-started",
        // res.locals.page2status="not-started",
        // res.locals.page3status="not-started",
        // res.locals.page4status="not-started",
        // res.locals.page5status="not-started"
        next();
    },

    index: function (req, res, next) {
        res.locals({
            indexSpecificData: someData
        });
        next();
    }

};

app.use(middleware.globalLocals)
app.use(loggerFunc)

app.use(flash());
app.use(passport.initialize());
app.use(passport.session());
// app.use((req, res, next) => {
//   if (req.path === '*/imgupdate') {
//     next();
//   } else {
//     lusca.csrf()(req, res, next);
//   }
// });
// app.use(lusca.xframe('SAMEORIGIN'));
// app.use(lusca.xssProtection(true));
app.use((req, res, next) => {
  res.locals.user = req.user;
  next();
});
app.use((req, res, next) => {
  // After successful login, redirect back to the intended page
  if (!req.user &&
      req.path !== '/login' &&
      req.path !== '/signup' &&
      !req.path.match(/^\/auth/) &&
      !req.path.match(/\./)) {
    req.session.returnTo = req.path;
  } else if (req.user &&
      req.path === '/account') {
    req.session.returnTo = req.path;
  }
  next();
});


app.use('/',router.index)
app.use('/account', router.account)
app.use('/auth', router.auth)
app.use('/books',router.books)
app.use('/register', router.register)
app.use('/authors', router.author)
app.use('/contact', router.contact)
app.use('/genres', router.genres)
app.use('/publishers', router.publisher)


app.use(function (err, req, res, next) {
  console.error(err.stack)
  res.status(500).send('Something broke!\n\n')
})

app.get('*', (req, res) => {
  res.render('error', {
      status: res.statusCode,
      title: 'Error',
      message: 'File not found'
  });
});

app.listen(port, function() {
    console.log(`Example app listening on port ${port}!`)
})
