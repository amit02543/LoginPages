const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PublisherSchema = new Schema({
    name: { type: String, required: true },
    founder: { type: Array, required: true },
    year: String,
    description: String,
    origin: String,
    headquarters: Array,
    location: Array,
    publication: String,
    employees: Number,
    website: String,
    subsidiaries: Array,
    acquisitions: Array,
    book_counts: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    views: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    created_at: { type: Date, default: Date.now },
    updated_at: Date
})

PublisherSchema.pre('save', function save(next) {
  const publisher = this;
  publisher.updated_at = Date.now;
})

module.exports = mongoose.model('Publisher', PublisherSchema);
