const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AuthorSchema = new Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    dob: { type: String, required: true },
    dod: String,
    about: { type: String, required: true },
    occupation: { type: Array, required: true },
    nationality: { type: Array, required: true },
    period: String,
    category: { type: Array, required: true },
    notableWorks: Array,
    location: String,
    authorImg: String,
    likes: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    dislikes: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    views: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    created_at: { type: Date, default: Date.now },
    updated_at: Date
})

// AuthorSchema.pre('save', function save(next) {
//   const author = this;
//   author.updated_at = Date.now;
//   console.log('before save: ', author)
// })

module.exports = mongoose.model('Author', AuthorSchema);
