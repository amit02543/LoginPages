const bookModel = require('./book')
const userQueryModel = require('./user-query')
const genreModel = require('./genre')
const countryModel = require('./country')
const tagModel = require('./tag')
const languageModel = require('./language')
const nationalityModel = require('./nationality')
const occupationModel = require('./occupation')
const loginModel = require('./login')
const authorModel = require('./author')
const publisherModel = require('./publisher')
const user = require('./user')

module.exports = {
  login:loginModel,
  books:bookModel,
  author: authorModel,
  publisher: publisherModel,
  userquery: userQueryModel,
  genres: genreModel,
  languages: languageModel,
  tags: tagModel,
  countries: countryModel,
  nationalities: nationalityModel,
  occupations: occupationModel,
  user: user
}
