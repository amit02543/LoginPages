const express = require('express')
const validators = require('../validators')
const chalk = require('chalk')

const joi = require('joi');
const bookDao = require('../dao').book
const Messages = require('../constant/messages')

const router = express.Router();
router.get('/', function(req, res, next) {
    const {type,order,layout,filter,q} = req.query
    validators.validateSearchPage(q)
    .then((value)=>{

      var sortParam =  {}
      var title,author,category,isbn
      sortParam[filter] = order;
      if(type.indexOf("title")>-1){
         title = q;
      } else if(type.indexOf("author")>-1){
         author = q;
      } else if(type.indexOf("category")>-1){
         category = q;
      } if(type.indexOf("isbn")>-1){
         isbn = q;
      }
        //return bookDao.searchBooksByFilterCriteria({title:title,category:category,author:author,sortParam:sortParam})
        return bookDao.searchBooksByTitle({title:title,category:category,author:author,sortParam:sortParam})
    })
    .then((books)=>{
      console.log('books: ', books.length)
      var searchType = type.substring(0, type.indexOf('-'))
            if (books.length > 0) {
                res.render(layout, {
                    title: 'Search',
                    message: 'Search Results',
                    data: books,
                    sample: JSON.stringify(books[0]),
                    query: q,
                    device: res.app.locals.device,
                    //deviceWidth: res.app.locals.deviceWidth,
                    total: books.length,
                    type: searchType
                });
            } else {
                res.render('failure', {
                    title: 'Search',
                    message: Messages.noResultErrorMsg
                });
            }
          })
          .catch((err)=>{
            console.log(chalk.red('Error occurred in promise'+err.message))
            res.send('Error')
          })

        });

router.post('/', function(req, res, next) {
  var fields = {};
  req.body.map( function(obj) {
     var name = obj.name, value = obj.value;
     if(value.indexOf(";")!=-1){
         var val = value.substring(0,value.lastIndexOf(";"));
         var arry = val.split(";");
         value = arry
       }
       fields[name] = value;
  });
  console.log(chalk.blue("data:: ", JSON.stringify(fields)))

  validators.validateRegisterPage(fields)
  .then((value) => {
    console.log(chalk.green('then method of post call ', value))
    res.json({
      'uri': 'register',
      'errorObj': "",
      'successMsg': Messages.bookUpdateSuccesMsg
    })
  })
  .catch((err) => {
    var errors = err.details;
    console.log(chalk.red('Error in post method: ', errors.length))
    var formattedError = errors.reduce((output,currentElem)=>{
  	   const fieldName = currentElem.path
      if(!output[fieldName]){
        output[fieldName] = []
      }
      output[fieldName].push(currentElem)
      return output
    },{})
    console.log(chalk.red('Error in post method: ', Object.keys(formattedError)))
    res.json({'uri': 'register', 'errorObj': formattedError})
  })
})

router.put('/', function(req, res, next) {
  bookDao.updateBookById(req.body)
  .then((book) => {
    res.send(book);
  })
  .catch((err) => {
    console.log(chalk.red('Error occured in update book promise ', err.message))
    res.send('error')
  })
})

router.delete('/', function(req, res, next) {
    bookDao.removeBookById(req.body.id)
    .then((book) =>  {
      res.send(book)
    })
    .catch((err) => {
      console.log(chalk.red('Error occured in removing book promise ', err.message))
      res.send('error')
    })
})

router.get('/:id', (req, res, next) => {
  bookDao.getBookById(req.params.id)
  .then((book) => {
    res.render('books2', {
          title: 'Book Detail',
          message: 'Book Detail',
          data: book
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getBookById method: ', err.message))
    res.send('error')
  })

});

router.put('/:id/download', (req, res, next) => {
  var id =  req.body.bookId
  return bookDao.updateDownloadsById(id)
    .then((value) => {
      console.log('downloads success: ', value, ' id : ', `${id}`)
      res.redirect(`/books/${id}`)
    })
    .catch((err) => {
      console.log('downloads catch: ', err.message, ' id : ', `${id}`)
      req.flash('error', { msg: Messages.reviewUpdateFailedMsg });
      return res.redirect(`/books/${id}`);
    })
})

router.put('/:id/like', (req, res, next) => {
  var id =  req.body.bookId
  return bookDao.updateLikesById(id)
    .then((value) => {
      console.log('likes success: ', value, ' id : ', `${id}`)
      res.redirect(`/books/${id}`)
    })
    .catch((err) => {
      console.log('likes catch: ', err.message, ' id : ', `${id}`)
      req.flash('error', { msg: Messages.reviewUpdateFailedMsg });
      return res.redirect(`/books/${id}`);
    })
})

router.put('/:id/dislike', (req, res, next) => {
  var id =  req.body.bookId
  return bookDao.updateDislikesById(id)
    .then((value) => {
      console.log('dislikes success: ', value, ' id : ', `${id}`)
      res.redirect(`/books/${id}`)
    })
    .catch((err) => {
      console.log('dislikes catch: ', err.message, ' id : ', `${id}`)
      req.flash('error', { msg: Messages.reviewUpdateFailedMsg });
      return res.redirect(`/books/${id}`);
    })
})

router.put('/:id/review', (req, res, next) => {
  const {rating, bookId, review} = req.body
  const id = req.params.id
  console.log("id: ", id, ' bookid: ', bookId)
  if(bookId===id){
    validators.validateRegisterPage.validateUserReview(req.body)
      .then((value) => {
        if(req.user){
          var userId = req.user.id;
          var name = req.user.profile.name
        } else {
          var userId = '';
          var name = 'Anonymous'
        }
        console.log('first then : ', value, ' id: ', userId, ' name: ', name)
        console.log('bookdao: ', bookDao)
        return bookDao.insertBookReview(value.bookId, value.rating, value.review, userId, name)
      })
      .then((value) => {
        console.log('second then : ', value)
        req.flash('success', { msg: Messages.reviewUpateSuccessMsg })
        res.redirect(`/books/${id}`)
      })
      .catch((err) => {
        req.flash('error', { msg: Messages.reviewUpdateFailedMsg });
        return res.redirect(`/books/${id}`);
      })
  } else {
    req.flash('errors', { msg: Messages.bookIdConflictError });
    return res.redirect(`/books/${id}`);
  }
})

router.get('/all', (req, res, next) => {
  bookDao.getBookById(req.params.id)
  .then((book) => {
    res.render('book', {
          title: 'Book Detail',
          message: 'Book Detail',
          data: book
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getBookById method: ', err.message))
    res.send('error')
  })

});

router.get('/top', (req, res, next) => {
  bookDao.getBookById(req.params.id)
  .then((book) => {
    res.render('book', {
          title: 'Book Detail',
          message: 'Book Detail',
          data: book
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getBookById method: ', err.message))
    res.send('error')
  })

});


router.get('/vote-wise', (req, res, next) => {
  bookDao.getBookById(req.params.id)
  .then((book) => {
    res.render('book', {
          title: 'Book Detail',
          message: 'Book Detail',
          data: book
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getBookById method: ', err.message))
    res.send('error')
  })

});


router.get('/year-wise', (req, res, next) => {
  bookDao.getBookById(req.params.id)
  .then((book) => {
    res.render('book', {
          title: 'Book Detail',
          message: 'Book Detail',
          data: book
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getBookById method: ', err.message))
    res.send('error')
  })

});



module.exports = router
