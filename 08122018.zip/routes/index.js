const main = require('./main')
const books = require('./book')
const register = require('./register')
const author = require('./author')
const publisher = require('./publisher')
const contact = require('./contact')
const genre = require('./genre')
const account = require('./account')
const auth = require('./auth')
//exports.index = main

module.exports = {
  index:main,
  books:books,
  register:register,
  author:author,
  publisher: publisher,
  contact: contact,
  genres: genre,
  account: account,
  auth: auth
}
