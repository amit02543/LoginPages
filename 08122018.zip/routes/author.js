const express = require('express')
const chalk = require('chalk')
const validators = require('../validators')
const cloudinary = require('cloudinary')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const upload = multer({dest: './upload/'});

const Messages = require('../constant/messages')
const authorDao = require('../dao').author

const MAGIC_NUMBERS = {
    jpg: 'ffd8ffe0',
    jpg1: 'ffd8ffe1',
    png: '89504e47',
    gif: '47494638'
}

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

function checkMagicNumbers(magic) {
  if (magic == MAGIC_NUMBERS.jpg || magic == MAGIC_NUMBERS.jpg1 || magic == MAGIC_NUMBERS.png || magic == MAGIC_NUMBERS.gif) return true
}

const router = express.Router();

var uploadFile = multer({
  storage: multer.memoryStorage()
}).single('authorImg')

router.get('/', function(req, res, next) {
  res.render('addAuthor', {
    title: 'Add Author',
    message: "Add a new author"
  })
})

router.post('/', uploadFile, function(req, res, next) {
  var data = req.body
  validators.author.validateAuthorDetails(data)
    .then((value) => {
      uploadFile(req, res, function(err) {
        var buffer = req.file.buffer
        var magic = buffer.toString('hex', 0, 4)
        var filename = req.file.fieldname + '-' + Date.now() + path.extname(req.file.originalname)

        if (checkMagicNumbers(magic)) {
          console.log('Condn: ', checkMagicNumbers(magic))
          fs.writeFile('./upload/' + filename, buffer, 'binary', function(err) {
            if (err) {
              console.log('error: ', err.message )
              throw err
            }
            console.log('filename: ', filename)
            cloudinary.uploader.upload('./upload/'+filename)
              .then((image) => {
                console.log('Result: ', image)
                console.log('value: ', value)
                value.category = value.category.split(";")
                value.occupation = value.occupation.split(";")
                value.nationality = value.nationality.split(";")
                value.notableWorks = value.notableWorks.split(";")
                value.authorImg = image.secure_url
                fs.unlink('./upload/'+filename, (err) => {
                  if (err) throw err;
                  console.log('successfully deleted '+ filename + ' from upload folder');
                });
                console.log('image url: ', value)
                return authorDao.insertAuthorDetails(value)
              })
              .then((xyz) => {
                console.log("Success data: ", xyz)
                res.redirect('/thank-you')
              })
              .catch((err) => {
                console.log('Error: ', err)
                res.render( 'addAuthor', {
                  title: 'Add Author',
                  data: data,
                  //errors: {"authorImg": [{message: "There is some issue with file upload. Please try after some time."}]},
                  message: "There is some issue with file upload. Please try after some time."
                });
              })
          })
        } else {
          res.render( 'addAuthor', {
            title: 'Add Author',
            data: data,
            errors: {"authorImg": [{message: Messages.invalidImageErrorMsg}]},
            message: JSON.stringify(data)
          });
        }
      })
    }).catch((err) => {
      var errors = err.details;
      console.log(chalk.red('Error in post method: ', errors.length))
      var formattedError = errors.reduce((output,currentElem)=>{
    	   const fieldName = currentElem.path
        if(!output[fieldName]){
          output[fieldName] = []
        }
        output[fieldName].push(currentElem)
        return output
      },{})
      console.log(chalk.red("errors: ", JSON.stringify(formattedError)))
      console.log("data: ", data)
      res.render( 'addAuthor', {
          title: 'Add Author',
          data: data,
          errors: formattedError
      });
    })
})

router.put('/', function(req, res, next) {
  console.log(chalk.blue("In Author PUT method"))
})

router.delete('/', function(req, res, next) {
  console.log(chalk.blue("In Author DELETE method"))
})

router.get('/summary', (req, res, next) => {
  authorDao.getAllAuthors()
  .then((authors) => {
    res.render('author', {
      title: 'Summary',
      author: authors[0]
    })
  })
})

router.get('/all', (req, res, next) => {
  authorDao.getAllAuthors()
  .then((authors) => {
    res.send(authors)
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getAllAuthors method: ', err.message))
    res.send('error')
  })
});

router.get('/top', (req, res, next) => {
  authorDao.getTopAuthors()
  .then((authors) => {
    res.send(authors)
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getTopAuthors method: ', err.message))
    res.send('error')
  })
});

router.get('/:id', (req, res, next) => {
  console.log('author id: ', req.params.id)
  authorDao.getAuthorDetailsById(req.params.id)
    .then((author) => {
      console.log('then block of author: ', author)
      res.send(author)
    })
    .catch((err) => {
      console.log('catch block of author: ', err.message)
    })
})


module.exports = router
