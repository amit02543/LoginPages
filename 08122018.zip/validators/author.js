const Joi = require('joi')
const joiOptions = { convert: true, abortEarly: false };

const addAuthorSchema = Joi.object().keys({
  firstName: Joi.string().min(2).max(50).required(),
  lastName: Joi.string().min(2).max(50).required(),
  dob: Joi.string().required(),
  dod: Joi.string().allow("").optional(),
  about: Joi.string().min(20).required(),
  occupation: Joi.string().required(),
  nationality: Joi.string().required(),
  period: Joi.string().required(),
  category: Joi.string().required(),
  notableWorks: Joi.string().required(),
  location: Joi.string().required()
  //authorImg: Joi.string().required()
})


const validateAuthorDetails = (query) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(query, addAuthorSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}


module.exports = { validateAuthorDetails }
