const Joi = require('joi')

const searchSchema = {query:Joi.string().min(3).max(20)};

const validateQuery = (q)=>{
  return new Promise((resolve,reject)=>{
  Joi.validate({ query: q }, searchSchema,(err, value) => {

      if(err){
        return reject(err)
      }
      return resolve(value)
  })
    })
}
function SearchValidator(){
  this.validateQuery= validateQuery
}
let searchValidator = new SearchValidator()
module.exports = validateQuery
