const express = require('express')
const router = express.Router();
const bluebird = require('bluebird');
const bcrypt = require('bcrypt-nodejs');
const flash = require('express-flash')
const crypto = bluebird.promisifyAll(require('crypto'));
const nodemailer = require('nodemailer');
const passport = require('passport');
const Constant = require('../constant/errors')
const Messages = require('../constant/messages')

const cloudinary = require('cloudinary')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const upload = multer({dest: './upload/'});

const User = require('../model/user');
const passportConfig = require('../config/passport')

const MAGIC_NUMBERS = {
    jpg: 'ffd8ffe0',
    jpg1: 'ffd8ffe1',
    png: '89504e47',
    gif: '47494638'
}

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

function checkMagicNumbers(magic) {
  console.log('magic: ', magic)
  if (magic == MAGIC_NUMBERS.jpg || magic == MAGIC_NUMBERS.jpg1 || magic == MAGIC_NUMBERS.png || magic == MAGIC_NUMBERS.gif) return true
}

router.get('/login', function(req, res, next) {
  if (req.user) {
    return res.redirect('/');
  }
  res.render('login', {
    title: 'Login',
    message: 'Login'
  })
})

router.post('/login', function(req, res, next) {
  passport.authenticate('local', (err, user, info) => {
    if (err) { return next(err); }
    if (!user) {
      req.flash('errors', info)
      return res.redirect('/account/login');
    }
    req.logIn(user, (err) => {
      if (err) { return next(err) }
      req.flash('success', { msg: Messages.loginSuccessMsg });
      //console.log('page id: ', req.session.returnTo)
      res.redirect(req.session.returnTo || '/');
    });
  })(req, res, next);
});

router.get('/logout', function(req, res) {
  console.log('logout')
  req.logout();
  res.redirect('/');
})

router.get('/signup', function(req, res) {
  if (req.user) {
    return res.redirect('/');
  }
  res.render('signup', {
    title: 'Sign Up',
    message: 'Create Account'
  })
})

router.post('/signup', function(req, res, next) {
  const user = new User({
    username: req.body.username,
    email: req.body.email,
    password: req.body.password
  });

  User.findOne({ email: req.body.email }, (err, existingUser) => {
    if (err) { return next(err); }
    if (existingUser) {
      req.flash('errors', { msg: Messages.signupExistingUserErrorMsg });
      return res.redirect('/account/signup');
    }
    user.save((err) => {
      if (err) { return next(err); }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        res.redirect('/');
      });
    });
  });
});

router.get('/profile/:action', passportConfig.isAuthenticated, function(req, res) {
  var userAction = req.params.action
  res.render('profile', {
    title: 'Account Management',
    message: 'Account Management',
    userAction: userAction
  })
})

router.post('/profile', passportConfig.isAuthenticated, (req, res, next) => {
  User.findById(req.user.id, (err, user) => {
    if (err) { return next(err); }
    user.email = req.body.email || '';
    user.profile.name = req.body.name || '';
    user.profile.gender = req.body.gender || '';
    user.profile.dob = req.body.dob || '';
    user.profile.contact = req.body.contact || '';
    user.profile.location = req.body.location || '';
    user.profile.website = req.body.website || '';
    user.save((err) => {
      if (err) {
        if (err.code === 11000) {
          console.log(Messages.existingUserErrorMsg)
          req.flash('errors', { msg: Messages.existingUserErrorMsg });
          return res.redirect('/account/profile/basic');
        }
        return next(err);
      }
      console.log(Messages.profileUpdateSuccessMsg)
      req.flash('success', { msg: Messages.profileUpdateSuccessMsg });
      res.redirect('/account/profile/basic');
    });
  });
});


router.post('/imgupdate', (req, res, next) => {
  console.log("image update")
  var upload = multer({
    storage: multer.memoryStorage()
  }).single('profilepic')
  upload(req, res, function(err) {
    var buffer = req.file.buffer
    var magic = buffer.toString('hex', 0, 4)
    var filename = req.file.fieldname + '-' + Date.now() + path.extname(req.file.originalname)

    if (checkMagicNumbers(magic)) {
      console.log('Condn: ', checkMagicNumbers(magic))
      fs.writeFile('./upload/' + filename, buffer, 'binary', function(err) {
        if (err) {
          console.log('error: ', err.message )
          throw err
        }
        console.log('filename: ', filename)
        cloudinary.uploader.upload('./upload/'+filename)
          .then((result) => {
            console.log('Result: ', result)
            User.findById(req.user.id, (err, user) => {
              if (err) { return next(err); }
              user.profile.picture = result.secure_url
              user.save((err) => {
                if (err) {
                  if (err.code === 11000) {
                    console.log(Messages.existingUserErrorMsg)
                    req.flash('errors', { msg: Messages.existingUserErrorMsg });
                    return res.redirect('/account/profile/basic');
                  }
                  return next(err);
                }
                console.log(Messages.profileUpdateSuccessMsg)
                req.flash('success', { msg: Messages.imgUpdateSuccessMsg });
                res.redirect('/account/profile/basic');
              });
          })
        })
          .catch((err) => {
            console.log('Error: ', err)
            req.flash('error', { msg: Messages.imgUpdateFailedMsg });
            res.render( 'profile', {
              title: 'Account Management',
              message: 'Account Management'
            });
          })
      })
    } else {
      req.flash('danger', { msg: "File format is invalid" });
      res.redirect('/account/profile/basic');
      res.render( 'reg-part-four', {
        title: 'Account Management',
        message: 'Account Management'
      });
    }
  })

})


router.post('/password', passportConfig.isAuthenticated, (req, res, next) => {
  console.log("password: ", req.user.password, " current: ", req.body.currentPassword, " new: ", req.body.password, " confirm: ", req.body.confirmPassword)
  console.log("comapre: ", bcrypt.compareSync(req.body.currentPassword, req.user.password))
  if(bcrypt.compareSync(req.body.currentPassword, req.user.password)){
    console.log("pass: ", req.body.password)
    User.findById(req.user.id, (err, user) => {
      if (err) { return next(err); }
      user.password = req.body.password;
      user.save((err) => {
        if (err) { return next(err); }
        console.log(Messages.passwordChangeSuccessMsg)
        req.flash('success', { msg: Messages.passwordChangeSuccessMsg });
        res.redirect('/account/profile/change');
      });
    });
  } else {
    console.log(Messages.passwordIncorrectErrorMsg)
    req.flash('error', { msg: Messages.passwordIncorrectErrorMsg})
    res.redirect('/account/profile/change')
  }
});

router.post('/delete', (req, res, next) => {
  User.remove({ _id: req.user.id }, (err) => {
    if (err) { return next(err); }
    req.logout();
    console.log(Messages.accountDeletedMsg)
    req.flash('info', { msg: Messages.accountDeletedMsg });
    res.redirect('/');
  });
});

router.get('/unlink/:provider', passportConfig.isAuthenticated, (req, res, next) => {
  const provider = req.params.provider;
  User.findById(req.user.id, (err, user) => {
    if (err) { return next(err); }
    user[provider] = undefined;
    user.tokens = user.tokens.filter(token => token.kind !== provider);
    user.save((err) => {
      if (err) { return next(err); }
      console.log(`${provider} account has been unlinked.`)
      req.flash('info', { msg: `${provider} account has been unlinked.` });
      res.redirect('/account/profile/social');
    });
  });
})

router.get('/reset/:token', function(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect('/');
  }
  User
    .findOne({ passwordResetToken: req.params.token })
    .where('passwordResetExpires').gt(Date.now())
    .exec((err, user) => {
      if (err) { return next(err); }
      if (!user) {
        console.log(Messages.pswdTokenExpireMg)
        req.flash('errors', { msg: Messages.pswdTokenExpireMg });
        return res.redirect('/account/forgot');
      }
      res.render('reset-password', {
        title: 'Password Reset'
      });
    });
});

router.post('/reset/:token', (req, res, next) => {
  const resetPassword = () =>
    User
      .findOne({ passwordResetToken: req.params.token })
      .where('passwordResetExpires').gt(Date.now())
      .then((user) => {
        if (!user) {
          console.log(Messages.pswdTokenExpireMg)
          req.flash('errors', { msg: Messages.pswdTokenExpireMg });
          return res.redirect('back');
        }
        user.password = req.body.password;
        user.passwordResetToken = undefined;
        user.passwordResetExpires = undefined;
        return user.save().then(() => new Promise((resolve, reject) => {
          req.logIn(user, (err) => {
            if (err) { return reject(err); }
            resolve(user);
          });
        }));
      });

  const sendResetPasswordEmail = (user) => {
    if (!user) { return; }
    const transporter = nodemailer.createTransport({
        service:"Gmail",
        auth:{
            type: process.env.GMAIL_AUTH_TYPE,
            user: process.env.ADMIN_EMAIL,
            clientId: process.env.GMAIL_AUTH_CLIENT_ID,
            clientSecret: process.env.GMAIL_AUTH_CLIENT_SECRET,
            refreshToken: process.env.GMAIL_AUTH_REFRESH_TOKEN
        }
      });

    const mailOptions = {
      to: user.email,
      from: Messages.adminEmailAddress,
      subject: Messages.successChangePswdSubject,
      //text: `Hello ${user.profile.name},\n\nThis is a confirmation that the password for your account ${user.email} has just been changed.\n`
      html:  `Hello <b>${user.profile.name}</b>,` + Messages.resetPswdSuccessTxtPre + ` ${user.email} ` + Messages.resetPswdSuccessTxtPost
    };
    return transporter.sendMail(mailOptions)
      .then(() => {
        console.log(Messages.pswdResetSuccessMsg)
        req.flash('success', { msg: Messages.pswdResetSuccessMsg });
      });
  };

  resetPassword()
    .then(sendResetPasswordEmail)
    .then(() => { if (!res.finished) res.redirect('/'); })
    .catch(err => next(err));
});

router.get('/forgot', (req, res) => {
  if (req.isAuthenticated()) {
    return res.redirect('/');
  }
  res.render('forgot-password', {
    title: 'Forgot Password'
  });
})

router.post('/forgot', (req, res, next) => {
  const createRandomToken = crypto
    .randomBytesAsync(16)
    .then(buf => buf.toString('hex'));
  console.log('email: ', req.body.email)
  const setRandomToken = token =>
    User
      .findOne({ email: req.body.email })
      .then((user) => {
        if (!user) {
          console.log(Messages.invalidEmailErrorMsg)
          req.flash('errors', { msg: Messages.invalidEmailErrorMsg });
        } else {
          user.passwordResetToken = token;
          user.passwordResetExpires = Date.now() + 3600000*24; // 1 day
          user = user.save();
        }
        return user;
      });

  const sendForgotPasswordEmail = (user) => {
    if (!user) { return; }
    const token = user.passwordResetToken;
    req.app.locals.email=user.email
    var transporter = nodemailer.createTransport({
        service:"Gmail",
        auth:{
            type: process.env.GMAIL_AUTH_TYPE,
            user: process.env.ADMIN_EMAIL,
            clientId: process.env.GMAIL_AUTH_CLIENT_ID,
            clientSecret: process.env.GMAIL_AUTH_CLIENT_SECRET,
            refreshToken: process.env.GMAIL_AUTH_REFRESH_TOKEN
        }
      });

    const mailOptions = {
      to: user.email,
      from: Messages.adminEmailAddress,
      subject: Messages.resetPasswordSubject,
      // text: `You are receiving this email because you (or someone else) have requested the reset of the password for your account.\n\n
      //   Please click on the following link, or paste this into your browser to complete the process:\n\n
      //   http://${req.headers.host}/account/reset/${token}\n\n
      //   If you did not request this, please ignore this email and your password will remain unchanged.\n`
      html: Messages.resetPasswordTextPre + `${req.headers.host}/account/reset/${token}>Reset Your Password</a>`+ Messages.resetPasswordTextPost + `<p style="font-style:italic" >http://${req.headers.host}/account/reset/${token}</p>` + Messages.resetPasswordInstruction
    };
    return transporter.sendMail(mailOptions)
      .then(() => {
        console.log(`An e-mail has been sent to ${user.email} with further instructions. `, Messages.adminEmailAddress)
        req.flash('info', { msg: `An e-mail has been sent to ${user.email} with further instructions.` });
      });
  };

  createRandomToken
    .then(setRandomToken)
    .then(sendForgotPasswordEmail)
    .then(() => { console.log("success"); res.redirect('/account/forgot/success')})
    .catch(() => res.redirect('/account/forgot/failure'));
});

router.get('/forgot/success', (req, res) => {
  if (req.isAuthenticated()) {
    return res.redirect('/');
  }
  res.render('password-email-sent', {
    title: 'Email Sent Success',
    email: req.app.locals.email
  });
})

router.get('/forgot/failure', (req, res) => {
  if (req.isAuthenticated()) {
    return res.redirect('/');
  }

  res.render('password-email-fail', {
    title: 'Email Sent Failure',
    email: req.app.locals.email
  });
})





router.get('/login/new', function(req, res, next) {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('newRegister', {
    title: 'Register',
    message: 'Register'
  })
})


router.get('/signup/new', function(req, res, next) {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('newSignUp', {
    title: 'Sign Up',
    message: 'Sign Up'
  })
})


router.get('/signIn/new', function(req, res, next) {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('newSignIn', {
    title: 'Login',
    message: 'Login'
  })
})


router.get("/forgotPassword/new", ( req, res, next) => {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('newForgotPassword', {
    title: 'Forgot Password',
    message: 'Forgot Password'
  })
})


router.get("/create", ( req, res, next ) => {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('newLogin', {
    title: 'Create Account',
    message: 'Create Account'
  })
})


router.get("/password-reset/success", ( req, res, next ) => {
  if( req.user ) {
    return res.redirect('/')
  }

  res.render( 'newPasswordResetSuccess', {
    title: 'Password Reset Success',
    message: 'Password Reset Success'
  })
})


router.get("/forgot-password/email/sent", ( req, res, next ) => {
  if ( req.user ) {
    return res.redirect('/')
  }

  res.render('newPasswordEmailSent', {
    title: 'Forgot Password Email Sent',
    message: 'Forgot Password Email Sent'
  })
})


router.get("/forgot-password/email/fail", ( req, res, next ) => {
  if ( req.user ) {
    return res.redirect('/')
  }

  res.render('newPasswordEmailFail', {
    title: 'Forgot Password Email Fail',
    message: 'Forgot Password Email Fail'
  })
})


router.get("/forgotPassword/new/test", ( req, res, next) => {
  if (req.user) {
    return res.redirect('/');
  }

  res.render('partials/newForgotPassword2', {
    title: 'Forgot Password',
    message: 'Forgot Password'
  })
})



module.exports = router
