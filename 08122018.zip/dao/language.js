var languageDao = {};
const Language = require('../model').languages;

languageDao.listLanguage = (query, pageLimit) => {
  return Language.find({
      language: new RegExp(query, "i")
  },
  { _id: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

module.exports = languageDao
