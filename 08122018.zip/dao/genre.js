var genreDao = {};
const Genre = require('../model').genres;

genreDao.getAllGenres = () => {
  return Genre.find({},{count: 0})
}

genreDao.getTopGenres = () => {
  return Genre.find({},{ _id: 1, genre: 1, count: 1}).sort({count: -1}).limit(10)
}

genreDao.getPopularGenres = () => {
  return Genre.find({},{ _id: 1, genre: 1, count: 1}).sort({count: -1}).limit(10)
}

genreDao.getCountWiseGenres = () => {
  return Genre.find({},{ _id: 1, genre: 1, count: 1}).sort({count: -1})
}

genreDao.getGenre = (genre) => {
  return Genre.find({
    genre: genre
  })
  .sort({genre: 1})
  .limit(10)
}

genreDao.listGenre = (query, pageLimit) => {
  return Genre.find({
      genre: new RegExp(query, "i")
  },
  { _id: 0, count: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

module.exports = genreDao
