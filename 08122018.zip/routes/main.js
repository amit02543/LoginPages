const express = require('express')
const router = express.Router();
const genreDao = require('../dao').genre
const countryDao = require('../dao').country
const languageDao = require('../dao').language
const nationalityDao = require('../dao').nationality
const occupationDao = require('../dao').occupation
const tagDao = require('../dao').tag
const Login = require('../model').login
const cors = require('cors')
const Messages = require('../constant/messages')

var whitelist = ['http://localhost:4000.com', 'http://pc221785:4000','http://localhost:3000.com']
var corsOptions = {
  origin: function (origin, callback) {
    console.log('Origin: ', origin)
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}

router.get('/', function(req, res) {
  res.redirect('/home')
})

router.get('/home', function(req, res) {
  res.render(
    'home', {
      title: 'Home',
      message: 'Hello there!'
    })
})

router.get('/about', function(req, res) {
  res.render(
    'about-us', {
      title: 'About Us',
      message: 'Hello there!'
    })
})

router.get('/thank-you', function(req, res) {
  res.render(
    'thank-you', {
      title: 'Thank You',
      message: 'Hello there!'
    })
})

router.get('/list/genres', function(req, res, next) {
  var {q, limit} = req.query;
  console.log("query: ", q, " limit: ", limit)
  limit = (limit != undefined) ? limit : 10;
  if(q.length>=2){
    genreDao.listGenre(q, limit)
      .then((result) => {
        // var finalResult = []
        // result.forEach(function(u) { finalResult.push(u.genre) })
        console.log("Result: ", result)
        res.send(result)
      })
  } else {
    res.send(Messages.queryLenError)
  }
})

router.get('/list/countries', function(req, res, next) {
    var {
        q,
        limit
    } = req.query
    limit = (limit != undefined) ? limit : 10
    if (q != undefined && q.length >= 2) {
        countryDao.listCountry(q, limit)
            .then((result) => {
                console.log('countries: ', result)
                res.send(result)
            })
    } else if (q == undefined) {
        console.log("list of all countries")
        countryDao.listAllCountry()
            .then((result) => {
                console.log('countries: ', result)
                res.send(result)
            })
    } else {
        res.send(Messages.queryLenError)
    }
})

router.get('/list/languages', function(req, res, next) {
  var {q, limit} = req.query
  limit = (limit!=undefined) ? limit : 10
  if (q.length>=2) {
    languageDao.listLanguage(q, limit)
      .then( (result) => {
        console.log('languages: ', result)
        res.send(result)
      })
  } else {
    res.send(Messages.queryLenError)
  }
})

router.get('/list/nationalities', function(req, res, next) {
  var {q, limit} = req.query
  limit = (limit!=undefined) ? limit : 10
  if (q.length>=2) {
    nationalityDao.listNationality(q, limit)
      .then( (result) => {
        console.log('nationalities: ', result)
        res.send(result)
      })
  } else {
    res.send(Messages.queryLenError)
  }
})

router.get('/list/occupations', function(req, res, next) {
  var {q, limit} = req.query
  limit = (limit!=undefined) ? limit : 10
  if (q.length>=2) {
    occupationDao.listOccupation(q, limit)
      .then( (result) => {
        console.log('occupations: ', result)
        res.send(result)
      })
  } else {
    res.send(Messages.queryLenError)
  }
})

router.get('/list/countries/all', function(req, res, next) {
  // var {q, limit} = req.query
  // limit = (limit!=undefined) ? limit : 10
  // if (q.length>=2) {
    countryDao.listAllCountry()
      .then( (result) => {
        console.log('languages: ', result.length)
        res.send(result)
      })
  // } else {
  //   res.send('Error: Query must contains 2 or more characters.')
  // }
})


router.get('/list/tags', function(req, res, next) {
  var {q, limit} = req.query
  limit = (limit!=undefined) ? limit : 10
  if (q.length>=2) {
    tagDao.listTag(q, limit)
      .then( (result) => {
        console.log('tags: ', result)
        res.send(result)
      })
  } else {
    res.send(Messages.queryLenError)
  }
})

module.exports = router
